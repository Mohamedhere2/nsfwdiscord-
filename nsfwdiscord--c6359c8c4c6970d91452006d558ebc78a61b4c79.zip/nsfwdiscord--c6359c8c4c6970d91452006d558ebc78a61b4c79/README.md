# Simple nsfw discord bot
> Very simple nsfw discord bot using the Nekos.life wrapper and discord.js

## Install

```
You have to install NodeJS and Git.
Create a folder.
Open Command Promt.
Type in: cd The path to your new folder. (Example: C:\Users\User\Desktop\New folder)
Press enter.
After that type in: git clone https://github.com/ghaku/nekos.life-discord-bot.git
Press enter.
When you see all Github files in your folder you installed the bot succesfully.
```

## Usage

Open config.json
And change the following values:

```
"prefix": "YOUR_PREFIX_HERE",
"token": "YOUR_TOKEN_HERE"
```

## Features

* Lot's of NSFW commands!
* Interact with users trough gifs (For example: !hug <@user>)!
* OwOfy text!
* Get random questions, facts and cat emojis!
* Cute pictures of cats, dogs and many more!

## Restrict to NSFW-channel

Open config.json
And change the following values:

* "true" - The bot only works in NSFW-channels.
* "false" - The bot works in all channels.

```
"nsfw_channel_only": "TRUE_OR_FALSE",
```

## Contributing

```
If you spot a any kind of mistake and know how to fix it edit the code and submit a pull request.
If you don't know how to fix it open an Issue and tell me about the mistake.
If you have any idea on how to make the code more efficiant please tell me about it.
```

## Author

Authored and maintained by ghaku.

> GitHub [@ghaku](https://github.com/ghaku)
